package api

import (
	"shortner/create"

	"github.com/gin-gonic/gin"
)

func AddLongURLToShortURL(ctx *gin.Context) {
	ctx.Writer.Header().Set("Access-Control-Allow-Origin", "*")

	url := ctx.PostForm("url")

	code := create.ToShortURL(url)
	ctx.JSON(200, gin.H{"code": code})
}
